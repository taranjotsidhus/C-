﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace highestElement
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private double Average(int[] iArray)
        {
            int total = 0;
            double average;

            for (int index = 0; index < iArray.Length; index++)
            {
                total += iArray[index];
            }

            average = (double)total / iArray.Length;
            return average;
        }

        private int highest (int[] iArray)
        {
            int highest = iArray[0];

            for (int index=1; index<iArray.Length;index++)
            {
                if(iArray[index] > highest)
                {
                    highest = iArray[index];
                }
            }

            return highest;
        }

       private int lowest(int[] iArray)
        {
            int lowest = iArray[0];
            for (int index = 1; index < iArray.Length; index++)
            {
                if (iArray[index]<lowest)
                {
                    lowest = iArray[index];
                }
            }

            return lowest;
        }

        

        private void button1_Click(object sender, EventArgs e)
        {
            const int SIZE = 5;
            int[] scores = new int[SIZE];
            int index = 0;
            int highestscore;
            int lowestscore;
            double averagescore;

            StreamReader inputFile;
            inputFile = File.OpenText("t.txt");
            while(!inputFile.EndOfStream && index < scores.Length)
            {
                scores[index] = int.Parse(inputFile.ReadLine());
                index++;
            }

            inputFile.Close();

            foreach(int value in scores)
            {
                listBox1.Items.Add(value);
            }

            highestscore = highest(scores);
            lowestscore = lowest(scores);
            averagescore = Average(scores);

            textBox2.Text = highestscore.ToString();
            textBox3.Text = lowestscore.ToString();
            textBox4.Text = averagescore.ToString();

        }

    }
}
